/*

  !- Credits By Skyzopedia
  https://wa.me/6285624297894
  
*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper")
const JsConfuser = require('js-confuser');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { exec, spawn, execSync } = require('child_process');
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')

const { LoadDataBase } = require('./library/message')
const { toAudio, toPTT, toVideo, ffmpeg } = require("./library/converter.js")
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');

module.exports = sock = async (sock, m, chatUpdate, store) => {
	try {
await LoadDataBase(sock, m)
const botNumber = await sock.decodeJid(sock.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
const prefix = "."
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""

const isCreator = [botNumber, ...global.owner.map(a => a.replace(/[^0-9]/g, '') + '@s.whatsapp.net')].includes(m.sender)
  ? true
  : m.isDeveloper
  ? true
  : false;
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
// fungsi helper di atas / awal file
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

//~~~~~~~~~ Console Message ~~~~~~~~//

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(botname2), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`${m.sender.split("@")[0]} =>`), chalk.blue.bold(`${prefix+command}`))
}

//~~~~~~~~~~~ Fake Quoted ~~~~~~~~~~//
if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

async function react(m) {
    const emojis = ['⚡', '🔥', '💥', '🦠', '☠️'];

    for (let i = 0; i < 3; i++) {
        const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
        await sock.sendMessage(m.chat, {
            react: {
                text: randomEmoji,
                key: m.key
            }
        });
        await new Promise(resolve => setTimeout(resolve, 400));
    }
}
//~~~~~~~~~ Function Main ~~~~~~~~~~//

const example = (teks) => {
return `\n *Contoh Penggunaan :*\n *${prefix+command}* ${teks}\n`
}

const Reply = async (teks) => {
return sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: qtext})
}

//~~~~~~~~~~~ Command ~~~~~~~~~~~//

switch (command) {
    
case 'allmenu': {
await react(m)
  let teks = `❏ \`XskyBew\`
  ⛦ .tiktok
  ⛦ .self
  ⛦ .public
  ⛦ .spotify
  ⛦ .hidetag
  ⛦ .rvo
  ⛦ .play
  ⛦ .pinterest
  ⛦ .cekresi
  ⛦ .cekidch
  ⛦ .iqc
  ⛦ .brat
  `;
  await sock.sendMessage(m.chat, {
    video: { url: 'https://files.catbox.moe/ykbuws.mp4' },
    gifPlayback: true,
    caption: teks,
    headerType: 6,
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterName: `Isahh Cantikkk`,
        newsletterJid: `120363401756921554@newsletter`,
      },
      externalAdReply: {
        title: "Simple v4 XskyBew",
        body: "Isahhh Sayangkuuu",
        thumbnailUrl: 'https://files.catbox.moe/v4cn6e.jpg',
        sourceUrl: `https://whatsapp.com/channel/0029VbBFghDDZ4LRcUkPEs18`,
        mediaType: 1,
        renderLargerThumbnail: true,
        mentionedJid: [m.chat]
      }
    }
  }, { quoted: m });
}
break;
    
case "public": {
if (!isCreator) return
sock.public = true
m.reply("Berhasil mengganti ke mode *public*")
}
break
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case "self": {
await react(m)
if (!isCreator) return
sock.public = false
m.reply("Berhasil mengganti ke mode *self*")
}
break

case 'tiktok':
case 'tt': {

  const args = (budy || '').trim();
  if (!text) return m.reply(example('Linknya'));

  const url = args.split(/\s+/).find(t => t.startsWith('http')) || args;

  await m.reply('🔎 Mengambil video dari TikTok...');
  await react(m)
  try {
    const api = `https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`;
    const res = await axios.get(api);
    const data = res.data;

    if (!data?.status || !data?.data?.urls?.length) {
      return await sock.sendMessage(m.chat, { text: '❌ Gagal mengambil video. Pastikan link TikTok valid.' }, { quoted: m });
    }

    const videoUrl = data.data.urls[0];
    const meta = data.data.metadata || {};
    const title = meta.title || 'Video TikTok';
    const creator = meta.creator || 'Tidak diketahui';
    const thumb = meta.thumbnail || null;
    const des = meta.description  || 'No description';

    await sock.sendMessage(m.chat, {
      video: { url: videoUrl },
      caption: `👤 \`${creator}\`\n- 🎬 ${title}`,
      jpegThumbnail: thumb ? await axios.get(thumb, { responseType: 'arraybuffer' }).then(r => r.data).catch(() => null) : null
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    await sock.sendMessage(m.chat, { text: '❌ Terjadi kesalahan saat memproses video TikTok.' }, { quoted: m });
  }
}
  break;
   
case 'spotify': {
 
  if (!text) return m.reply(example('duka last child'));

  await sock.sendMessage(m.chat, { text: `🎧 Mencari lagu *${text}*...` }, { quoted: m });
  await react(m)
  try {
    const res = await fetch(`https://faa-jian.my.id/search/spotify?q=${encodeURIComponent(text)}`);
    const data = await res.json();

    if (!data.status || !data.download) {
      return await sock.sendMessage(m.chat, { text: `❌ Lagu tidak ditemukan di Spotify.` }, { quoted: m });
    }

    // buat file sementara
    const safeTitle = data.title.replace(/[^\w\s]/g, "");
    const filePath = path.join(process.cwd(), `${safeTitle}.mp3`);

    // download audio
    const response = await fetch(data.download);
    if (!response.ok) throw new Error("Gagal mengunduh file audio Spotify.");

    const fileStream = fs.createWriteStream(filePath);
    await new Promise((resolve, reject) => {
      response.body.pipe(fileStream);
      response.body.on("error", reject);
      fileStream.on("finish", resolve);
    });

    // caption futuristik
    const caption = `
╭───❖ 〘 *XskyBew Music* 〙
│ 🎵 *${data.title}*
│ 👤 Artist : ${data.artist}
│ 💿 Album : ${data.album}
│ ⏱️ Duration : ${data.duration}
│ 📅 Release : ${data.release_date}
╰─────────────❖
`;

    // kirim audio + caption (gunakan file path)
    await sock.sendMessage(
      m.chat,
      {
        audio: { url: filePath },
        mimetype: "audio/mpeg",
        ptt: false,
      },
      { quoted: m }
    );
    await sleep(1000)
    await sock.sendMessage(
      m.chat, { text : caption }, { quoted: m }
    ); 

    // hapus file sementara
    fs.unlinkSync(filePath);

  } catch (e) {
    console.error(e);
    await sock.sendMessage(m.chat, { text: `⚠️ Terjadi kesalahan saat memutar lagu Spotify.\n${e.message}` }, { quoted: m });
  }
}
  break;
 
case "rvo": case "readviewonce": {
if (!m.quoted) return m.reply(example("dengan repky pesan"))
let msg = m.quoted.message || m.quoted.fakeObj.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce && m.quoted.mtype !== "viewOnceMessageV2") return m.reply("Pesan itu bukan viewonce!")
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return sock.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return sock.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return sock.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break;

case "ht":
case "h":
case "hidetag": {
    if (!m.isGroup) {
        return m.reply("Fitur ini hanya bisa digunakan di dalam grup!");
    }
    if (!isCreator && !m.isAdmin) {
        return m.reply("Fitur ini hanya untuk admin grup!");
    }
    if (!text) {
        return m.reply("isinen teks e su");
    }
    try {
        if (!m.metadata || !m.metadata.participants) {
            return m.reply("Gagal mendapatkan daftar anggota grup. Coba lagi.");
        }
        const members = m.metadata.participants.map(v => v.id);
        
        await sock.sendMessage(m.chat, {
            text: text,
            mentions: members
        }, {
            quoted: null
        });
    } catch (error) {
        console.error("Error sending hidetag message:", error);
        return m.reply("Terjadi kesalahan saat mencoba mengirim pesan hidetag.");
    }
}
break;

case 'play': {
  if (!text) return m.reply(example('Judul Musik'));

  await sock.sendMessage(m.chat, { text: `🔍 Mencari lagu *${text}*...` }, { quoted: m });
  await react(m)
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000); // 10 detik timeout

    const res = await fetch(`https://faa-jian.my.id/search/playt?q=${encodeURIComponent(text)}`, { signal: controller.signal });
    clearTimeout(timeout);

    if (!res.ok) throw new Error(`HTTP ${res.status} - ${res.statusText}`);

    const data = await res.json();
    if (!data.status || !data.result)
      return await sock.sendMessage(m.chat, { text: `⚠️ Lagu tidak ditemukan.` }, { quoted: m });

    const r = data.result;
    const caption = `
🎧 *${r.title}*
👤 Channel : ${r.channel}
⏱️ Durasi : ${r.duration}
📅 Upload : ${r.uploaded}
👁️ Views : ${r.views.toLocaleString()}
🔗 URL : ${r.url}
`;

    await sock.sendMessage(m.chat, {
      image: { url: r.thumbnail },
      caption,
      footer: '© 2025 XskyBew',
      buttons: [
        { buttonId: `.playmp3 ${text}`, buttonText: { displayText: '🎵 Play MP3' }, type: 1 },
        { buttonId: `.playmp4 ${text}`, buttonText: { displayText: '🎬 Play MP4' }, type: 1 }
      ],
      headerType: 4
    }, { quoted: m });

  } catch (e) {
    console.error('Error di fitur play:', e);
    let msg = '❌ Gagal mengambil data.';
    if (e.name === 'AbortError') msg = '⚠️ Timeout: API tidak merespons.';
    await sock.sendMessage(m.chat, { text: msg }, { quoted: m });
  }
}
break;

case 'playmp3': {

  if (!text) return m.reply(example("❌ Masukkan judul lagu!"))

  await sock.sendMessage(m.chat, { text: `🎶 Mengunduh audio MP3 *${text}*...` }, { quoted: m });
  await react(m)
  try {
    const res = await fetch(`https://faa-jian.my.id/search/playt?q=${encodeURIComponent(text)}`);
    const data = await res.json();
    if (!data.status || !data.result) return await sock.sendMessage(m.chat, { text: "⚠️ Lagu tidak ditemukan." }, { quoted: m });

    const r = data.result;
    const mp3Url = r.audio_video?.mp3;
    if (!mp3Url) return await sock.sendMessage(m.chat, { text: "🎵 File MP3 tidak tersedia." }, { quoted: m });

    // nama file aman
    const safeTitle = r.title.replace(/[^\w\s]/g, "");
    const filePath = path.join(process.cwd(), `${safeTitle}.mp3`);

    // download
    const response = await fetch(mp3Url);
    if (!response.ok) throw new Error("Gagal mengunduh MP3.");
    const fileStream = fs.createWriteStream(filePath);
    await new Promise((resolve, reject) => {
      response.body.pipe(fileStream);
      response.body.on("error", reject);
      fileStream.on("finish", resolve);
    });

    const caption = `
🎧 *${r.title}*
👤 ${r.channel}
⏱️ ${r.duration}
🔗 ${r.url}`;

    // kirim audio
    await sock.sendMessage(m.chat, {
      audio: { url: filePath },
      mimetype: "audio/mpeg",
      ptt: false,
    }, { quoted: m });
    await sleep(1000);
    await sock.sendMessage(m.chat, { text: caption }, { quoted: m });

    fs.unlinkSync(filePath);

  } catch (e) {
    console.error(e);
    await sock.sendMessage(m.chat, { text: `❌ Gagal mengirim MP3.\n${e.message}` }, { quoted: m });
  }
}
break;

case 'playmp4': {

  if (!text) return m.reply(example("❌ Masukkan judul lagu!"));

  await sock.sendMessage(m.chat, { text: `🎬 Mengunduh video MP4 *${text}*...` }, { quoted: m });

  try {
    const res = await fetch(`https://faa-jian.my.id/search/playt?q=${encodeURIComponent(text)}`);
    const data = await res.json();
    if (!data.status || !data.result) return await sock.sendMessage(m.chat, { text: "⚠️ Lagu tidak ditemukan." }, { quoted: m });

    const r = data.result;
    const mp4Url = r.audio_video?.mp4;
    if (!mp4Url) return await sock.sendMessage(m.chat, { text: "🎬 File MP4 tidak tersedia." }, { quoted: m });

    const safeTitle = r.title.replace(/[^\w\s]/g, "");
    const filePath = path.join(process.cwd(), `${safeTitle}.mp4`);

    // download
    const response = await fetch(mp4Url);
    if (!response.ok) throw new Error("Gagal mengunduh MP4.");
    const fileStream = fs.createWriteStream(filePath);
    await new Promise((resolve, reject) => {
      response.body.pipe(fileStream);
      response.body.on("error", reject);
      fileStream.on("finish", resolve);
    });

    const caption = `
🎬 *${r.title}*
👤 ${r.channel}
⏱️ ${r.duration}
🔗 ${r.url}`;

    // kirim video
    await sock.sendMessage(m.chat, {
      video: { url: filePath },
      mimetype: "video/mp4",
      caption,
    }, { quoted: m });

    fs.unlinkSync(filePath);

  } catch (e) {
    console.error(e);
    await sock.sendMessage(m.chat, { text: `❌ Gagal mengirim MP4.\n${e.message}` }, { quoted: m });
  }
}
break;

case 'pinterest':
case 'pin': {
  if (!text) return m.reply(example('Fotonya'))

  try {
    const axios = require('axios')
    const { data } = await axios.get(`https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(text)}&type=image`)
    if (!data || !data.data || !data.data.length) return m.reply('Gak ketemu hasilnya 😅')

    const hasil = data.data.slice(0, 5) // ambil max 8 biar gak berat
    const cards = []
    for (let item of hasil) {
      const title = item.grid_title || item.seo_alt_text || item.description || 'Pinterest Image'
      const pinner = item.pinner?.full_name || item.pinner?.username || 'Unknown'
      const link = item.link || item.pin || 'https://pinterest.com'
      const imgUrl = item.image_url

      const media = await prepareWAMessageMedia({ image: { url: imgUrl }}, { upload: sock.waUploadToServer })
      cards.push({
        header: proto.Message.InteractiveMessage.Header.fromObject({
          title: `📌 ${title}\n👤 ${pinner}`,
          hasMediaAttachment: true,
          ...media
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [{
            name: "cta_url",
            buttonParamsJson: `{\"display_text\":\"🌐 Lihat di Pinterest\",\"url\":\"${link}\",\"merchant_url\":\"https://www.google.com\"}`
          }]
        })
      })
    }

    const msg = await generateWAMessageFromContent(m.chat, {
      ephemeralMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({
              text: `✨ *Hasil Pinterest untuk:* ${text}\nGeser kanan untuk lihat gambar lainnya ➡️`
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
              text: 'XskyBew Pinterest Carousel'
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards
            })
          })
        }
      }
    }, { userJid: m.sender, quoted: m })

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (err) {
    console.error(err)
    m.reply('❌ Gagal memuat hasil Pinterest, coba lagi nanti.')
  }
}
break

  
  case 'stalktiktok':
case 'ttstalk': {
  if (!text) return m.reply(example('mrbeast'))

  try {
    const axios = require('axios')
    const res = await axios.get(`https://api.siputzx.my.id/api/stalk/tiktok?username=${encodeURIComponent(text)}`)
    if (!res.data?.status || !res.data?.data) return m.reply('User tidak ditemukan 😅')

    const user = res.data.data.user
    const stats = res.data.data.stats

    const caption = `\`👤 ${user.nickname}\`\n(@${user.uniqueId})
${user.verified ? '✅ Verified Account' : ''}
──────────────
📦 ID: ${user.id}
🌎 Bahasa: ${user.language || '-'}
📹 Video: ${stats.videoCount.toLocaleString()}
❤️ Likes: ${stats.heartCount.toLocaleString()}
👥 Followers: ${stats.followerCount.toLocaleString()}
👤 Following: ${stats.followingCount.toLocaleString()}
🧍 Friends: ${stats.friendCount.toLocaleString()}
🔗 Bio Link: ${user.bioLink?.link || '-'}
📜 Bio:${user.signature || '-'}
──────────────
📅 Dibuat: ${new Date(user.createTime * 1000).toLocaleString('id-ID')}
    `.trim()

    await sock.sendMessage(m.chat, {
      image: { url: user.avatarLarger },
      caption,
      footer: '© XskyBew TikTok Stalk',
      buttons: [
        {
          buttonId: `.stalktiktok ${user.uniqueId}`,
          buttonText: { displayText: '🔁 Refresh Data' },
          type: 1
        }
      ],
      headerType: 4,
      viewOnce: true,
      buttons: [
        {
          name: "cta_url",
          buttonParamsJson: `{\"display_text\":\"🌐 Buka Profil TikTok\",\"url\":\"https://www.tiktok.com/@${user.uniqueId}\",\"merchant_url\":\"https://www.tiktok.com/@${user.uniqueId}\"}`
        }
      ]
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply('❌ Gagal mengambil data, coba lagi nanti.')
  }
 }
  break
  
  case "demote":
case "promote": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await sock.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await sock.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break

case 'cekresi':
case 'resi': {
  if (!text) {
    const buttons = [
      { buttonId: `.cekresi 1234567890`, buttonText: { displayText: 'Contoh Cek Resi' }, type: 1 }
    ];
    await sock.sendMessage(m.chat, {
      text: example('1234567890'),
      buttons,
      footer: 'Pilih kurir setelah mengetik nomor resi.'
    }, { quoted: m });
    return;
  }

  // kalau cuma resi dikirim tanpa kurir
  if (!text.includes(' ')) {
    const noresi = text.trim();
    const kurirList = ['JNE', 'JNT', 'TIKI', 'POS', 'SICEPAT', 'IDEXPRESS', 'SAP', 'Wahana'];
    const buttons = kurirList.map(k => ({
      buttonId: `.cekresi ${noresi} ${k}`,
      buttonText: { displayText: k },
      type: 1
    }));

    await sock.sendMessage(m.chat, {
      text: `Pilih kurir untuk resi *${noresi}*`,
      buttons,
      footer: 'Klik tombol di bawah ini'
    }, { quoted: m });
    return;
  }

  // kalau sudah ada kurir
  let [resi, kurir] = text.split(' ');
  try {
    await m.reply('🔍 Sedang melacak paket...');
    let url = `https://api.siputzx.my.id/api/check/resi?resi=${resi}&courier=${kurir}`;
    let res = await fetch(url);
    let json = await res.json();

    if (!json.status) return m.reply(`❌ Resi tidak ditemukan di kurir *${kurir}*`);

    let d = json.data;
    let info = `📦 *Cek Resi ${d.courier}*\n\n🆔 Resi: ${d.resi}\n📮 Status: ${d.status}\n💬 ${d.message}\n\n⏰ ${json.timestamp}`;
    await sock.sendMessage(m.chat, { text: info }, { quoted: m });
  } catch (err) {
    console.error(err);
    m.reply('⚠️ Gagal melacak resi.');
  }
}
break;
  
case 'brat':
case 'bratvid': {
  if (!text) return m.reply(example('Hello World'));

  // Deteksi jenis brat
  let type = 'brat';
  if (/bratvid/.test(command)) type = 'bratvid';

  // Tentukan URL API-nya
  const apiUrl = `https://api.privatezia.biz.id/api/generator/${type}?text=${encodeURIComponent(text)}`;

  // Kirim sebagai stiker (statis/brat) atau animasi (bratvid)
  try {
    await sock.sendAsSticker(m.chat, apiUrl, m, {
      packname: 'XskyBew',
      author: 'XskyBew'
    });
  } catch (e) {
    console.error(e);
    m.reply('❌ Gagal membuat stiker Brat.');
  }
  }
  break;
  
  
  case 'iqc': {
  if (!text) return m.reply(example(`12:00|80|Hello World`));
  
  const [time, batteryPercentage, ...textParts] = text.split("|").map(a => a.trim());
  const teks = textParts.join("|");
  
  if (!time || !batteryPercentage || !teks) 
    return m.reply(`Format salah!\n\nGunakan:\n${prefix}iqc jam|baterai|teks\nContoh:\n${prefix}iqc 12:00|80|Hello World`);
  
  const processing = await sock.sendMessage(m.chat, { text: "⏳ Membuat IQC..." });

  try {
    const apiUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&messageText=${encodeURIComponent(teks)}&batteryPercentage=${encodeURIComponent(batteryPercentage)}&carrierName=Wi-Fi&signalStrength=3&emojiStyle=apple`;
    
    await sock.sendMessage(m.chat, {
      image: { url: apiUrl },
      caption: `\n\n🕐 ${time}\n🔋 ${batteryPercentage}%\n💬 ${teks}`,
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    await sock.sendMessage(m.chat, { text: "❌ Gagal membuat IQC, coba lagi nanti!" });
  }
}
break;

case "cekidch": case "idch": {
if (!text) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await sock.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return m.reply(teks)
}
break

// Di switch atau if command
case 'hd':
case 'hdr': {
  await sock.sendMessage(m.chat, {
    react: { text: `⏳`, key: m.key }
  });

  let urlGambar = '';

  // Cek jika reply ke pesan dengan gambar
  if (m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage) {
    urlGambar = await sock.downloadAndSaveMediaMessage(m.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage);
    urlGambar = await uploadToCatbox(urlGambar);  // Upload ke Catbox agar punya URL public (lihat fungsi bawah)
  } 
  // Atau jika kirim URL di teks
  else if (m.text.split(' ').length > 1) {
    urlGambar = m.text.split(' ')[1];
  } 
  else {
    await sock.sendMessage(m.chat, { text: '❌ Cara pakai: Reply gambar atau kirim'});
    return;
  }

  if (!urlGambar.startsWith('http')) {
    await sock.sendMessage(m.chat, { text: '❌ URL gambar invalid!' }, { quoted: m });
    return;
  }

  // Encode URL untuk API
  const apiUrl = `https://api.privatezia.biz.id/api/generator/hdr?url=${encodeURIComponent(urlGambar)}`;

  try {
    // Kirim gambar hasil HDR
    await sock.sendMessage(m.chat, {
      image: { url: apiUrl },
      caption: `Done`,
    }, { quoted: m });

    await sock.sendMessage(m.chat, {
      react: { text: `✅`, key: m.key }
    });
  } catch (err) {
    console.error(err);
    await sock.sendMessage(m.chat, { text: '❌ Gagal generate HD! Coba URL lain atau API sedang down.' }, { quoted: m });
  }
}
break;
//~~~~~~~~~~~//

default:
if (m.text.toLowerCase() == "bot") {
m.reply("Online Kak ✅")
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
}
} catch (err) {
console.log(util.format(err));
}}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
});