module.exports = {
  API_ID: 29216254,
  API_HASH: "6a9a907ee8b2eaa07860bfbe0efb7fdf",
};