const fetch = require("node-fetch");

module.exports = {
    name: "play",
    command: "play",
    desc: "Putar lagu dari judul (YouTube)",
    ownerOnly: false,

    execute: async (client, event, prefix) => {
        const chatId = event.message.chatId;
        const text = event.message.message.split(" ").slice(1).join(" ");
        if (!text) {
            return client.sendMessage(chatId, {
                message: `<blockquote>❌ Masukkan judul lagu.\nContoh: ${prefix}play duka last child</blockquote>`,
                parseMode: "html"
            });
        }

        try {
            await client.sendMessage(chatId, { 
                message: `<blockquote>🎧 Mencari lagu <b>${text}</b>...</blockquote>`, 
                parseMode: "html" 
            });

            const res = await fetch(`https://api-beta-test-vert.vercel.app/search/playt?q=${encodeURIComponent(text)}`);
            const data = await res.json();

            if (!data.status || !data.result?.audio?.download_url) {
                return client.sendMessage(chatId, { 
                    message: `<blockquote>❌ Lagu tidak ditemukan atau audio tidak tersedia.</blockquote>`, 
                    parseMode: "html" 
                });
            }

            const info = data.result;
            const audioUrl = info.audio.download_url;

            // ambil file ke Buffer
            const audioRes = await fetch(audioUrl);
            if (!audioRes.ok) throw new Error("Gagal mengambil audio stream.");

            const audioBuffer = Buffer.from(await audioRes.arrayBuffer());

            const caption = `<blockquote>
🎵 <b>${info.title}</b>
📺 <b>Channel:</b> ${info.channel}
⏱️ <b>Durasi:</b> ${info.duration}
📅 <b>Upload:</b> ${info.uploaded}
🔗 <a href="${info.url}">Open YouTube</a>
</blockquote>`;

            // kirim buffer langsung ke Telegram
            await client.sendFile(chatId, {
                file: audioBuffer,
                caption,
                fileName: `${info.title.replace(/[^\w\s]/g, "")}.mp3`,
                mimeType: "audio/mpeg",
                parseMode: "html"
            });

        } catch (e) {
            console.error(e);
            await client.sendMessage(chatId, {
                message: `<blockquote>⚠️ Terjadi kesalahan saat memutar lagu.\n${e.message}</blockquote>`,
                parseMode: "html"
            });
        }
    }
};