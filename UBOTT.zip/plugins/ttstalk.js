const axios = require("axios");

module.exports = {
  name: "ttstalk",
  command: "ttstalk",
  desc: "Stalk akun TikTok",
  ownerOnly: false,

  async execute(client, event, prefix) {
    const msg = event.message;
    const chatId = msg.chatId;
    const text = (msg.message || "").split(" ").slice(1).join(" ").trim();

    if (!text) {
      return await client.sendMessage(chatId, {
        message: `<blockquote>Gunakan: ${prefix || "."}ttstalk &lt;username&gt;\nContoh: ${prefix || "."}ttstalk yahyaalialmthr</blockquote>`,
        parseMode: "html",
      });
    }

    const username = text.replace(/^@/, "");
    const api = `https://api.vreden.my.id/api/v1/stalker/tiktok?username=${encodeURIComponent(username)}`;

    // kirim pesan loading
    const loadingMsg = await client.sendMessage(chatId, {
      message: "<blockquote>⏳ Mengambil data akun TikTok...</blockquote>",
      parseMode: "html",
    });

    try {
      const res = await axios.get(api, { timeout: 15000 });
      const data = res.data;

      if (!data || !data.status || !data.result) {
        throw new Error((data && data.message) || "Gagal mengambil data dari API");
      }

      const r = data.result;
      const s = r.statistics || {};

      const created = r.created_at
        ? new Date(r.created_at * 1000).toLocaleString("id-ID", {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit",
          })
        : "Tidak diketahui";

      const caption = `<blockquote>
<b>👤 TikTok Stalker — Detail Akun</b>

<b>🆔 ID:</b> ${r.id || "-"}
<b>📛 Nama:</b> ${r.nickname || "-"}
<b>🔖 Username:</b> @${r.username || username}
<b>✅ Verified:</b> ${r.verified ? "Ya" : "Tidak"}
<b>🌐 Bahasa:</b> ${r.language || "-"}
<b>📅 Dibuat pada:</b> ${created}

<b>📊 Statistik</b>
• Followers: ${s.follower ?? "-"}
• Following: ${s.following ?? "-"}
• Likes: ${s.like ?? "-"}
• Posts: ${s.post ?? "-"}
• Friends: ${s.friend ?? "-"}

<b>📝 Bio</b>
${r.biography ? r.biography.replace(/</g, "&lt;").replace(/>/g, "&gt;") : "Tidak ada"}

<b>🔗 Link Profil</b>
<a href="https://tiktok.com/${r.username || username}">Klik di sini</a>

<b>🖼️ Avatar URL:</b>
${r.avatar?.larger || r.avatar?.medium || r.avatar?.thumbnail || "-"}
</blockquote>`;

      const imageUrl =
        r.image_account ||
        r.avatar?.larger ||
        r.avatar?.medium ||
        r.avatar?.thumbnail ||
        null;

      // kirim gambar dengan caption
      if (imageUrl) {
        await client.sendFile(chatId, {
          file: imageUrl,
          caption,
          parseMode: "html",
        });
      } else {
        await client.sendMessage(chatId, { message: caption, parseMode: "html" });
      }
    } catch (e) {
      console.error("ttstalk error:", e?.toString?.() || e);

      await client.sendMessage(chatId, {
        message: `<blockquote>❌ Terjadi kesalahan: ${e.message || e}</blockquote>`,
        parseMode: "html",
      });
    }
  },
};