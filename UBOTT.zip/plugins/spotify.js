const fetch = require("node-fetch");
const fs = require("fs");
const path = require("path");

module.exports = {
    name: "spotify",
    command: "spotify",
    desc: "Putar lagu dari Spotify",
    ownerOnly: false,

    execute: async (client, event, prefix) => {
        const chatId = event.message.chatId;
        const text = event.message.message.split(" ").slice(1).join(" ");
        if (!text) {
            await client.sendMessage(chatId, { 
                message: `<blockquote>❌ Masukkan judul lagu yang ingin diputar.\nContoh: ${prefix}spotify duka last child</blockquote>`, 
                parseMode: "html" 
            });
            return;
        }

        try {
            await client.sendMessage(chatId, { 
                message: `<blockquote>🎧 Mencari lagu <b>${text}</b>...</blockquote>`, 
                parseMode: "html" 
            });

            const res = await fetch(`https://faa-jian.my.id/search/spotify?q=${encodeURIComponent(text)}`);
            const data = await res.json();

            if (!data.status || !data.download) {
                await client.sendMessage(chatId, { 
                    message: `<blockquote>❌ Lagu tidak ditemukan di Spotify.</blockquote>`, 
                    parseMode: "html" 
                });
                return;
            }

            // Download audio ke file sementara
            const filePath = path.join(process.cwd(), `${data.title.replace(/[^\w\s]/g, "")}.mp3`);
            const file = fs.createWriteStream(filePath);
            const response = await fetch(data.download);

            if (!response.ok) throw new Error("Gagal mengunduh file audio Spotify.");

            await new Promise((resolve, reject) => {
                response.body.pipe(file);
                response.body.on("error", reject);
                file.on("finish", resolve);
            });

            // Caption gaya futuristik khas BEW SYSTEM
            const caption = `<blockquote>
🎵 <b>${data.title}</b>
👤 <b>Artist:</b> ${data.artist}
💿 <b>Album:</b> ${data.album}
⏱️ <b>Duration:</b> ${data.duration}
📅 <b>Release:</b> ${data.release_date}
🔗 <a href="${data.spotify_url}">Open Spotify</a>
</blockquote>`;

            await client.sendFile(chatId, { 
                file: filePath,
                caption: caption,
                parseMode: "html"
            });

            // hapus file setelah dikirim
            fs.unlinkSync(filePath);

        } catch (e) {
            console.error(e);
            await client.sendMessage(chatId, { 
                message: `<blockquote>⚠️ Terjadi kesalahan saat memutar lagu Spotify.\n${e.message}</blockquote>`, 
                parseMode: "html" 
            });
        }
    }
};