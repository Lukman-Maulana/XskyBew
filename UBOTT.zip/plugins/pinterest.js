const axios = require("axios");

module.exports = {
  name: "pinterest",
  command: "pinterest",
  desc: "Cari gambar dari Pinterest",

  async execute(client, event, prefix) {
    const chatId = event.message.chatId;
    const text = event.message.message.split(" ").slice(1).join(" ");
    
    if (!text) {
      return await client.sendMessage(chatId, { 
        message: `<blockquote>❌ Masukkan kata kunci pencarian.\nContoh: ${prefix}pinterest aesthetic girl</blockquote>`, 
        parseMode: "html" 
      });
    }

    // Kirim pesan loading
    const loadingMsg = await client.sendMessage(chatId, { 
      message: `<blockquote>🔍 Mencari gambar <b>${text}</b> di Pinterest...</blockquote>`, 
      parseMode: "html" 
    });

    try {
      const res = await axios.get(`https://apibeta.vercel.app/search/pinterest?q=${encodeURIComponent(text)}`);
      const data = res.data;

      if (!data.status || !data.result?.length) {
        return await client.editMessage(chatId, {
          message: loadingMsg.id,
          text: `<blockquote>❌ Tidak ditemukan hasil untuk <b>${text}</b>.</blockquote>`,
          parseMode: "html"
        });
      }

      const random = data.result[Math.floor(Math.random() * data.result.length)];
      const caption = `<blockquote>
📸 <b>${random.caption || "(Tanpa caption)"}</b>

👤 <b>${random.fullname}</b> (@${random.upload_by})
👥 <b>Followers:</b> ${random.followers}
🔗 <a href="${random.source}">Kunjungi Pinterest</a>
</blockquote>`;

      // Ganti pesan loading jadi hasil akhir
      await client.editMessage(chatId, {
        message: loadingMsg.id,
        text: `<blockquote>✅ Gambar ditemukan, mengirim...</blockquote>`,
        parseMode: "html"
      });

      // Kirim gambar
      await client.sendFile(chatId, {
        file: random.image,
        caption: caption,
        parseMode: "html"
      });

    } catch (e) {
      console.error(e);
      await client.editMessage(chatId, {
        message: loadingMsg.id,
        text: `<blockquote>⚠️ Terjadi kesalahan saat mengambil data.\n${e.message}</blockquote>`,
        parseMode: "html"
      });
    }
  }
};