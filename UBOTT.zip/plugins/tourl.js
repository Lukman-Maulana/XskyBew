const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");
const path = require("path");

module.exports = {
    name: "tourl",
    command: "tourl",
    desc: "Ubah media menjadi link",
    ownerOnly: false,

    async execute(client, event, prefix) {
        const chatId = event.message.chatId;
        const replyMsg = await event.message.getReplyMessage();

        if (!replyMsg || !replyMsg.media) {
            await client.sendMessage(chatId, {
                message: `<blockquote>❗ Balas foto, video, audio, atau file dengan perintah <b>${prefix}tourl</b>.</blockquote>`,
                parseMode: "html"
            });
            return;
        }

        const statusMsg = await client.sendMessage(chatId, {
            message: "<blockquote>📤 Mengupload file</blockquote>",
            parseMode: "html"
        });

        try {
            // ambil file dan buffer-nya
            const fileInfo = await client.getMessages(chatId, { ids: replyMsg.id });
            const file = fileInfo[0] || fileInfo;
            const fileData = await client.downloadMedia(file);

            // ambil nama dan ekstensi file
            let filename = "file";
            let ext = "";

            if (replyMsg.media.document?.attributes?.length) {
                const doc = replyMsg.media.document;
                const attr = doc.attributes.find(a => a.fileName);
                if (attr?.fileName) filename = attr.fileName;
            }

            if (replyMsg.media.document?.mimeType) {
                const mime = replyMsg.media.document.mimeType;
                if (mime.includes("image")) ext = ".jpg";
                else if (mime.includes("video")) ext = ".mp4";
                else if (mime.includes("audio")) ext = ".mp3";
                else if (mime.includes("pdf")) ext = ".pdf";
                else if (mime.includes("text")) ext = ".txt";
            }

            // jika file name punya ekstensi asli
            if (filename.includes(".")) {
                ext = "." + filename.split(".").pop();
            }

            // fallback terakhir: dari type media
            if (!ext || ext === ".dat") {
                if (replyMsg.media.photo) ext = ".jpg";
                else if (replyMsg.media.video) ext = ".mp4";
                else if (replyMsg.media.audio) ext = ".mp3";
                else if (replyMsg.media.voice) ext = ".ogg";
                else ext = ".bin";
            }

            const tempFilePath = `./temp_${Date.now()}${ext}`;
            fs.writeFileSync(tempFilePath, fileData);

            // upload ke catbox
            const form = new FormData();
            form.append("reqtype", "fileupload");
            form.append("fileToUpload", fs.createReadStream(tempFilePath));

            const res = await axios.post("https://catbox.moe/user/api.php", form, {
                headers: form.getHeaders(),
                timeout: 60000
            });

            fs.unlinkSync(tempFilePath);

            const url = res.data.trim();
            const finalUrl = url.endsWith(ext) ? url : url + ext;

            await client.editMessage(chatId, {
                message: statusMsg.id,
                text: `<blockquote>✅ Upload berhasil!\n🔗 <a href="${finalUrl}">${finalUrl}</a></blockquote>`,
                parseMode: "html"
            });
        } catch (err) {
            console.error(err);
            await client.editMessage(chatId, {
                message: statusMsg.id,
                text: `<blockquote>❌ Gagal upload: ${err.message}</blockquote>`,
                parseMode: "html"
            });
        }
    }
};