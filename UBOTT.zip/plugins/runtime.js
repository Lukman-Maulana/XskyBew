module.exports = {
  name: "runtime",
  command: "runtime",
  desc: "lama bot berjalan",
  ownerOnly: true,

  execute: async (client, event, prefix, startTime) => {
    try {
      const chatId = event.message.chatId;
      const uptime = process.uptime();
      const h = Math.floor(uptime / 3600);
      const m = Math.floor((uptime % 3600) / 60);
      const s = Math.floor(uptime % 60);

      // 🧠 Hitung total durasi maksimum (asumsi 24 jam per siklus)
      const totalSeconds = 86400;
      const percent = Math.min((uptime / totalSeconds) * 100, 100);
      const filled = Math.round(percent / 10);
      const bar = "▰".repeat(filled) + "▱".repeat(10 - filled);

      const waktu = `${h} jam ${m} menit ${s} detik`;

      const teks = `
<blockquote><b>⚙️ STATUS RUNTIME BOT</b>

<b>⏱ Lama berjalan :</b> ${waktu}
<b>📶 Progress :</b> ${bar} ${percent.toFixed(1)}%
<b>📦 Process ID :</b> <code>${process.pid}</code>
<b>🧠 Memory :</b> ${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB
<b>🕹️ Node.js :</b> ${process.version}
<b>🛰️ Platform :</b> ${process.platform}
</blockquote>`;

      await client.sendMessage(chatId, {
        message: teks.trim(),
        parseMode: "html",
      });

      console.log(`[RUNTIME] ${waktu} (${percent.toFixed(1)}%)`);
    } catch (err) {
      console.error("[RUNTIME ERROR]", err);
      await client.sendMessage(event.message.chatId, {
        message: `<blockquote>⚠️ Gagal mengambil data runtime bot.</blockquote>`,
        parseMode: "html",
      });
    }
  },
};