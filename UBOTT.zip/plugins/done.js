//Credit By VinnOffcial

//#NP HAPUS WM ANJG❗❗
//HARGAIN YANH BUAT❗❗
const moment = require('moment');

module.exports = {
    name: "done",
    command: "done",
    desc: "Format After TRX",
    ownerOnly: true,
    execute: async (client, event, prefix, startTime) => {
        const msg = event.message.message;
        const chatId = event.message.chatId;
        
        try {
            // Kirim pesan processing
            const processingMsg = await client.sendMessage(chatId, {
                message: "<blockquote>memproses...</blockquote>",
                parseMode: "html"
            });
            
            // Tunggu 5 detik
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            const args = msg.split(" ").slice(1);
            if (args.length === 0 || !msg.includes(",")) {
                await client.editMessage(chatId, {
                    message: processingMsg.id,
                    text: "<blockquote>Penggunaan: .done name item,price,payment</blockquote>",
                    parseMode: "html"
                });
                return;
            }
            
            const inputText = args.join(" ");
            const parts = inputText.split(",");
            
            if (parts.length < 2) {
                await client.editMessage(chatId, {
                    message: processingMsg.id,
                    text: "<blockquote>Penggunaan: .done name item,price,payment</blockquote>",
                    parseMode: "html"
                });
                return;
            }
            
            const name_item = parts[0].trim();
            const price = parts[1].trim();
            const payment = parts.length > 2 ? parts[2].trim() : "Lainnya";
            const time = moment().format("YYYY-MM-DD HH:mm:ss");
            
            const response = 
                `<blockquote>「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 」</blockquote>\n` +
                `<blockquote>📦 <b>ʙᴀʀᴀɴɢ : ${name_item}</b>\n` +
                `💸 <b>ɴᴏᴍɪɴᴀʟ : ${price}</b>\n` +
                `🕰️ <b>ᴡᴀᴋᴛᴜ : ${time}</b>\n` +
                `💬 <b>ᴘᴀʏᴍᴇɴᴛ : ${payment}</b>\n</blockquote>\n` +
                `<blockquote>ᴛᴇʀɪᴍᴀᴋᴀsɪʜ ᴛᴇʟᴀʜ ᴏʀᴅᴇʀ</blockquote>`;
            
            await client.editMessage(chatId, {
                message: processingMsg.id,
                text: response,
                parseMode: "html"
            });
            
        } catch (error) {
            console.error('Error in done command:', error);
            await client.sendMessage(chatId, {
                message: `<blockquote>❌ Error: ${error.message}</blockquote>`,
                parseMode: "html"
            });
        }
    }
};