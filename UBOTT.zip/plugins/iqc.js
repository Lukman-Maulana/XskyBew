module.exports = {
name: "iqc",
command: "iqc",
desc: "Iphone Quote",
ownerOnly: true,

async execute(client, event, prefix) {  
    const msg = event.message.message;  
    const chatId = event.message.chatId;  
      
    const args = msg.slice(3 + prefix.length).trim();  
    const [time, batteryPercentage, ...teksParts] = args.split("|").map(p => p.trim());  
    const teks = teksParts.join("|");  
      
    if (!time || !batteryPercentage || !teks) {  
        await client.sendMessage(chatId, {   
            message: `<blockquote>Format: ${prefix}iqc jam|baterai|teks</blockquote>\n<blockquote>Contoh: ${prefix}iqc 12:00|80|Hello World</blockquote>`,   
            parseMode: "html"   
        });  
        return;  
    }  
      
    const processing = await client.sendMessage(chatId, {   
        message: "<blockquote>Memproses membuat IQC...</blockquote>",   
        parseMode: "html"   
    });  
      
    try {  
        const apiUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&messageText=${encodeURIComponent(teks)}&batteryPercentage=${encodeURIComponent(batteryPercentage)}&carrierName=Wi-Fi&signalStrength=3&emojiStyle=apple`;  
          
        await client.editMessage(chatId, {   
            message: processing.id,   
            text: teks,   
            file: apiUrl   
        });  
    } catch (error) {  
        console.error(error);  
        await client.editMessage(chatId, {   
            message: processing.id,   
            text: "<blockquote>Gagal membuat IQC. Coba lagi nanti!</blockquote>",   
            parseMode: "html"   
        });  
    }  
}

};