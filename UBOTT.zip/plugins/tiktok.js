const axios = require("axios");

module.exports = {
  name: "tiktok",
  command: "tiktok",
  desc: "Download video TikTok ",
  ownerOnly: true,

  async execute(client, event, prefix) {
    try {
      const msg = event.message;
      const chatId = msg.chatId;
      const text = msg.message || "";
      const args = text.split(/\s+/).slice(1);
      const link = args[0];

      if (!link) {
        return client.sendMessage(chatId, { message: "<blockquote>⚠️ Kirim link TikTok-nya!</blockquote>", parseMode: "html" });
      }

      await client.sendMessage(chatId, { message: "<blockquote>⏳ Sedang mengambil video...</blockquote>", parseMode: "html" });

      const api = `https://api.vreden.my.id/api/v1/download/tiktok?url=${encodeURIComponent(link)}`;
      const res = await axios.get(api);
      const data = res.data?.result;

      if (!data) return client.sendMessage(chatId, { message: "<blockquote>❌ Tidak mendapatkan data dari API.</blockquote>", parseMode: "html" });

      // ambil link video tanpa watermark
      const video = data.data.find(x => x.type === "nowatermark")?.url;
      if (!video) return client.sendMessage(chatId, { message: "<blockquote>❌ Tidak ada video no watermark.</blockquote>", parseMode: "html" });

      const caption = `<blockquote>🎬 <b>${data.title}</b>\n👤 <b>@${data.author.nickname}</b>\n❤️ ${data.stats.likes} | 💬 ${data.stats.comment} | 👀 ${data.stats.views}</blockquote>`;

      // Kirim langsung lewat URL
      await client.sendFile(chatId, {
        file: video,
        caption,
        parseMode: "html"
      });

    } catch (e) {
      console.error(e);
      await client.sendMessage(event.message.chatId, { message: `❌ Terjadi error: ${e.message}` });
    }
  }
};