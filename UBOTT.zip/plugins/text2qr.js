const axios = require("axios");

module.exports = {
    name: "text2qr",
    command: "text2qr",
    desc: "Ubah teks jadi QR Code",
    ownerOnly: false,

    async execute(client, event, prefix) {
        const chatId = event.message.chatId;
        const args = event.message.message.split(" ").slice(1);
        const text = args.join(" ");

        if (!text) {
            await client.sendMessage(chatId, {
                message: `<blockquote>❌ Gunakan format:\n${prefix}text2qr <teks>\n\nContoh:\n${prefix}text2qr Hello World</blockquote>`,
                parseMode: "html"
            });
            return;
        }

        try {
            // API gratis tanpa key
            const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(text)}`;

            await client.sendFile(chatId, {
                file: qrUrl,
                caption: `<blockquote>✅ <b>QR Code berhasil dibuat!</b>\n🧾 <b>Teks:</b> ${text}</blockquote>`,
                parseMode: "html"
            });

            console.log(`[QR] ${event.message.senderId} membuat QR dari teks: "${text}"`);
        } catch (err) {
            console.error("Error di text2qr:", err);
            await client.sendMessage(chatId, {
                message: `<blockquote>⚠️ Terjadi kesalahan saat membuat QR Code.</blockquote>`,
                parseMode: "html"
            });
        }
    }
};