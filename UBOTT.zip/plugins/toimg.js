const fs = require("fs");
const path = require("path");
const { fileTypeFromBuffer } = require("file-type");

module.exports = {
  name: "toimg",
  command: "toimg",
  desc: "Ubah stiker menjadi gambar",
  ownerOnly: true,

  execute: async (client, event) => {
    const reply = event.message.replyTo;
    const chatId = event.message.chatId;

    if (!reply) {
      return await client.sendMessage(chatId, {
        message: "<blockquote>⚠️ Balas ke stiker yang mau diubah.</blockquote>",
        parseMode: "html",
      });
    }

    try {
      const repliedMsg = await event.message.getReplyMessage();
      const media = repliedMsg.media;

      if (!media) {
        return await client.sendMessage(chatId, {
          message: "<blockquote>❌ Pesan tidak mengandung media.</blockquote>",
          parseMode: "html",
        });
      }

      // Download stiker sebagai buffer
      const buffer = await client.downloadMedia(media);
      const type = await fileTypeFromBuffer(buffer);

      if (!type || type.mime !== "image/webp") {
        return await client.sendMessage(chatId, {
          message: "<blockquote>⚠️ Media bukan stiker WEBP.</blockquote>",
          parseMode: "html",
        });
      }

      const outPath = path.join(__dirname, "../tmp_toimg.png");
      fs.writeFileSync(outPath, buffer);

      // Kirim balik sebagai foto
      await client.sendMessage(chatId, {
        file: outPath,
        caption: "<blockquote>✅ Stiker berhasil diubah ke gambar!</blockquote>",
        parseMode: "html",
      });

      fs.unlinkSync(outPath);
    } catch (err) {
      console.error("❌ Error toimg:", err);
      await client.sendMessage(chatId, {
        message: `<blockquote>❌ Terjadi error: ${err.message}</blockquote>`,
        parseMode: "html",
      });
    }
  },
};