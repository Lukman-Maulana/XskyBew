const { Api } = require("telegram");
const moment = require("moment-timezone");

module.exports = {
  name: "id",
  command: "id",
  desc: "Cek ID user",
  ownerOnly: false,

  async execute(client, event, prefix) {
    try {
      const msg = event.message;
      const chatId = msg.chatId;
      const text = msg.message || "";
      const isPrivate = msg.isPrivate || false;
      let targetId;

      // 🧩 Tentukan target
      if (msg.replyToMsgId) {
        const replied = await client.getMessages(chatId, {
          ids: msg.replyToMsgId,
        });
        targetId = replied[0]?.senderId;
      } else if (text.includes("@")) {
        const username = text.split("@")[1].split(" ")[0];
        const resolved = await client
          .invoke(new Api.contacts.ResolveUsername({ username }))
          .catch(() => null);
        targetId = resolved?.users?.[0]?.id;
      } else {
        targetId = msg.senderId;
      }

      // Jika tidak ada target, keluar
      if (!targetId)
        return client.sendMessage(chatId, {
          message: `<blockquote>❌ Tidak dapat menemukan target user.</blockquote>`,
          parseMode: "html",
        });

      // 🔍 Ambil data user/grup
      const fullInfo = await client.invoke(new Api.users.GetFullUser({ id: targetId }));
      const user = fullInfo.users[0];
      const about = fullInfo.fullUser.about || "Tidak ada bio.";
      const now = moment().tz("Asia/Jakarta");

      // 💡 Info waktu akun dibuat (kadang tidak tersedia)
      let createdAt = "❓ Tidak diketahui";
      if (user?.accessHash) {
        // pseudo-estimasi berdasar ID (optional fun info)
        const base = 1_000_000_000;
        const createdYear = 2014 + Math.floor(user.id / base);
        createdAt = `~${createdYear}`;
      }

      // 🧠 Rangkai teks
      let info = `<blockquote><b>👁‍🗨 INFORMASI USER</b>\n\n`;
      info += `<b>🆔 ID:</b> <code>${user.id}</code>\n`;
      info += `<b>🔗 Link:</b> <a href="tg://user?id=${user.id}">Klik di sini</a>\n`;
      info += `<b>📛 Nama:</b> ${user.firstName || "-"} ${user.lastName || ""}\n`;
      if (user.username) info += `<b>🏷️ Username:</b> @${user.username}\n`;
      info += `<b>🗓️ Est. Akun Dibuat:</b> ${createdAt}\n`;
      info += `<b>💬 Bio:</b> ${about}\n\n`;
      info += `<b>🌐 DC:</b> ${user.photo?.dcId || "N/A"}\n`;
      info += `<b>🌏 Bahasa:</b> ${user.langCode || "N/A"}\n`;
      info += `<b>⭐ Premium:</b> ${user.premium ? "✅" : "❌"}\n`;
      info += `<b>🤖 Bot:</b> ${user.bot ? "✅" : "❌"}\n`;
      info += `<b>☑️ Verified:</b> ${user.verified ? "✅" : "❌"}\n`;
      info += `<b>⚠️ Scam:</b> ${user.scam ? "✅" : "❌"}\n`;
      info += `<b>👺 Fake:</b> ${user.fake ? "✅" : "❌"}\n</blockquote>`;

      // 💬 Kirim hasil
      await client.sendMessage(chatId, {
        message: info,
        parseMode: "html",
      });

      console.log(`[ID] Info dikirim untuk ${user.username || user.id}`);
    } catch (err) {
      console.error("[ID ERROR]", err);
      await client.sendMessage(event.message.chatId, {
        message: `<blockquote>⚠️ Terjadi kesalahan saat mengambil data user.</blockquote>`,
        parseMode: "html",
      });
    }
  },
};