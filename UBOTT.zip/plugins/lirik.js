const axios = require("axios");

module.exports = {
  name: "lirik",
  command: "lirik",
  desc: "Cari lirik lagu",
  ownerOnly: false,

  async execute(client, event, prefix) {
    try {
      const chatId = event.chatId;
      const rawText = event.message?.message || "";
      const query = rawText.replace(new RegExp(`^\\${prefix}lirik\\s*`, "i"), "").trim();

      if (!query) {
        return client.sendMessage(chatId, {
          parseMode: "html",
          message: `<blockquote>📝 Gunakan:\n${prefix}lirik <judul lagu></blockquote>`,
        });
      }

      // kirim pesan loading (tidak akan di-edit / dihapus)
      await client.sendMessage(chatId, {
        parseMode: "html",
        message: `<blockquote>⏳ Mencari lirik untuk <b>${escapeHtml(query)}</b></blockquote>`,
      });

      // panggil API
      const res = await axios.get(`https://apizsa.vercel.app/search/lyrics?title=${encodeURIComponent(query)}`, { timeout: 15000 });
      const data = res.data;

      if (!data || !data.status || !data.result?.length) {
        return client.sendMessage(chatId, {
          parseMode: "html",
          message: `<blockquote>❌ Lirik untuk <b>${escapeHtml(query)}</b> tidak ditemukan.</blockquote>`,
        });
      }

      const first = data.result[0];
      const title = first.trackName || first.name || query;
      const artist = first.artistName || "-";
      const album = first.albumName || "-";
      const duration = first.duration ? `${Math.floor(first.duration/60)}:${String(first.duration%60).padStart(2,"0")}` : "-";
      const lyrics = first.plainLyrics || "❌ Lirik tidak tersedia.";

      // header
      const header = `<blockquote>🎵 <b>${escapeHtml(title)}</b> — ${escapeHtml(artist)}\n💽 Album: ${escapeHtml(album)}\n⏱️ Durasi: ${escapeHtml(duration)}\n──────────────────────</blockquote>\n`;

      // gabungkan header + lirik, lalu chunk jika perlu
      const full = header + escapeHtml(lyrics);
      const chunks = chunkString(full, 3900); // amankan di bawah limit

      // kirim setiap chunk sebagai pesan terpisah (urut)
      for (const part of chunks) {
        await client.sendMessage(chatId, {
          parseMode: "html",
          message: part,
        });
      }
      
    } catch (err) {
      console.error(err);
      // jika terjadi error, beri tahu user
      const chatId = event.chatId || (event.message && event.message.peerId);
      if (chatId) {
        await client.sendMessage(chatId, {
          parseMode: "html",
          message: `<blockquote>❌ Terjadi kesalahan saat mengambil lirik.</blockquote>`,
        });
      }
    }

    // helper: escape HTML (supaya aman saat parseMode html)
    function escapeHtml(text) {
      if (!text && text !== "") return "";
      return String(text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
    }

    // helper: pecah string menjadi potongan ukuran max
    function chunkString(str, size) {
      const chunks = [];
      let index = 0;
      while (index < str.length) {
        chunks.push(str.slice(index, index + size));
        index += size;
      }
      return chunks;
    }
  },
};