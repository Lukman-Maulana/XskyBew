const os = require("os");
const fs = require("fs");

module.exports = {
  name: "consoleView",
  async run() {
    const c = {
      r: "\x1b[31m", g: "\x1b[32m", y: "\x1b[33m", b: "\x1b[34m",
      c: "\x1b[36m", w: "\x1b[37m", dim: "\x1b[2m", bold: "\x1b[1m", reset: "\x1b[0m"
    };

    function bar(p, w = 40) {
      const f = Math.round((p / 100) * w);
      return `${c.g}${"█".repeat(f)}${c.dim}${"░".repeat(Math.max(0, w - f))}${c.reset}`;
    }

    function formatBytes(b) {
      if (!b) return "0 B";
      const u = ["B", "KB", "MB", "GB"];
      let i = 0;
      while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
      return `${b.toFixed(2)} ${u[i]}`;
    }

    function getCpu() {
      const cpus = os.cpus();
      let idle = 0, total = 0;
      for (const cpu of cpus) {
        for (const t in cpu.times) total += cpu.times[t];
        idle += cpu.times.idle;
      }
      return { idle: idle / cpus.length, total: total / cpus.length };
    }

    function getMem() {
      const t = os.totalmem(), f = os.freemem();
      return { used: t - f, total: t, percent: ((t - f) / t) * 100 };
    }

    function uptime() {
      const s = os.uptime();
      const d = Math.floor(s / 86400);
      const h = Math.floor((s % 86400) / 3600);
      const m = Math.floor((s % 3600) / 60);
      const sec = Math.floor(s % 60);
      return `${d}d ${h}h ${m}m ${sec}s`;
    }

    const logo = `
${c.c}
╔═╗╔═╗──╔╗─────╔══╗
╚╗╚╝╔╝──║║─────║╔╗║
─╚╗╔╝╔══╣║╔╦╗─╔╣╚╝╚╦══╦╗╔╗╔╗
─╔╝╚╗║══╣╚╝╣║─║║╔═╗║║═╣╚╝╚╝║
╔╝╔╗╚╬══║╔╗╣╚═╝║╚═╝║║═╬╗╔╗╔╝
╚═╝╚═╩══╩╝╚╩═╗╔╩═══╩══╝╚╝╚╝
───────────╔═╝║
───────────╚══╝
${c.reset}${c.y}${c.bold}POWERED BY XSKYBE W${c.reset}
${c.dim}────────────────────────────────────────────────────────────${c.reset}
`;

    const infoStatic = `
${c.g}💻   Hostname:${c.reset} ${os.hostname()}
${c.g}🧠   CPU Core:${c.reset} ${os.cpus().length}
${c.g}🧩   Platform:${c.reset} ${os.platform()} ${os.arch()}
${c.g}🔧   Bot Name:${c.reset} XSKYBEW
${c.g}👤   Developer:${c.reset} BEW
${c.g}⏱️   Started:${c.reset} ${new Date().toLocaleString()}
${c.dim}────────────────────────────────────────────────────────────${c.reset}
`;

    console.clear();
    console.log(logo);
    console.log(infoStatic);

    let prevCpu = getCpu();

    for (;;) {
      const nowCpu = getCpu();
      const idle = nowCpu.idle - prevCpu.idle;
      const total = nowCpu.total - prevCpu.total;
      const cpuP = total > 0 ? (1 - idle / total) * 100 : 0;
      prevCpu = nowCpu;

      const mem = getMem();

      const fakeNet = {
        down: (Math.random() * 8 + 2).toFixed(2),
        up: (Math.random() * 3 + 0.5).toFixed(2),
      };

      console.clear();
      console.log(logo);
      console.log(infoStatic);

      console.log(`${c.y}📊   CPU Usage:${c.reset} ${cpuP.toFixed(1)}%`);
      console.log(bar(cpuP));
      console.log(`${c.y}💾   RAM Usage:${c.reset} ${mem.percent.toFixed(1)}% (${formatBytes(mem.used)} / ${formatBytes(mem.total)})`);
      console.log(bar(mem.percent));

      console.log(`${c.y}🌐   VPS Speed:${c.reset} ↓${fakeNet.down} MB/s | ↑${fakeNet.up} MB/s`);
      console.log(`${c.y}🕓   Uptime:${c.reset} ${uptime()}`);

      console.log(`${c.dim}────────────────────────────────────────────────────────────${c.reset}`);
      console.log(`${c.c}${c.bold}XSKYBEW BOT ONLINE — STABLE ✅${c.reset}`);

      await new Promise((r) => setTimeout(r, 5000));
    }
  }
};