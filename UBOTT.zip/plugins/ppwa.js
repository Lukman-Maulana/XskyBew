module.exports = {
    name: "ppwa",
    command: "ppwa",
    desc: "Get foto Profile",
    ownerOnly: true,
    
    async execute(client, event, prefix) {
        const chatId = event.message?.chatId;
        const msg = (event.message?.message || "").trim();
        const args = msg.slice(prefix.length + 4).trim();

        if (!args) {
            await client.sendMessage(chatId, {
                message: `<blockquote>Masukkan nomor WhatsApp!\nContoh: ${prefix}ppwa 628xxxx</blockquote>`,
                parseMode: "html"
            });
            return;
        }

        try {
            const processingMsg = await client.sendMessage(chatId, {
                message: "<blockquote>Memproses mengambil foto profil WhatsApp...</blockquote>",
                parseMode: "html"
            });

            const apiUrl = `https://jianapis.vercel.app/search/ppwa?q=${encodeURIComponent(args)}`;

            await client.editMessage(chatId, {
                message: processingMsg.id,
                file: apiUrl
            });

        } catch {
            await client.sendMessage(chatId, {
                message: "<blockquote>❌ Gagal mengambil foto profil WhatsApp</blockquote>",
                parseMode: "html"
            });
        }
    }
};