module.exports = {
    name: "pakustadz",
    command: "pakustadz",
    desc: "Kata kata",
    ownerOnly: true,
    
    async execute(client, event, prefix) {
        const msg = event.message.message;
        const chatId = event.message.chatId;
        
        const text = msg.slice(10 + prefix.length).trim();
        
        if (!text) {
            await client.sendMessage(chatId, { 
                message: `<blockquote>Format: ${prefix}pakustadz [teks]</blockquote>`, 
                parseMode: "html" 
            });
            return;
        }
        
        try {
            const processingMsg = await client.sendMessage(chatId, { 
                message: "<blockquote>Memproses membuat gambar Ustadz...</blockquote>", 
                parseMode: "html" 
            });
            
            const encodedText = encodeURIComponent(text);
            const apiUrl = `https://api.zenzxz.my.id/maker/ustadz?text=${encodedText}`;
            
            await client.editMessage(chatId, {
                message: processingMsg.id,
                file: apiUrl
            });
            
        } catch (error) {
            await client.sendMessage(chatId, { 
                message: "<blockquote>❌ Gagal membuat gambar Ustadz</blockquote>", 
                parseMode: "html" 
            });
        }
    }
};