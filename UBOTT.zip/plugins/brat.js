const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports = {
    name: "brat",
    command: "brat",
    ownerOnly: true,
    async execute(client, event, prefix) {
        const msg = event.message.message;
        const chatId = event.message.chatId;
        const text = msg.slice(5 + prefix.length).trim();
        if (!text) {
            await client.sendMessage(chatId, { 
                message: `<blockquote>Format: ${prefix}brat [teks]</blockquote>`, 
                parseMode: "html" 
            });
            return;
        }

        const processing = await client.sendMessage(chatId, { 
            message: "<blockquote>Memproses membuat stiker...</blockquote>", 
            parseMode: "html" 
        });

        try {
            const apiUrl = `https://apizsa.vercel.app/tools/brat?text=${encodeURIComponent(text)}`;
            const res = await axios.get(apiUrl, { responseType: "arraybuffer" });

            const filePath = path.join(__dirname, "brat.webp");
            fs.writeFileSync(filePath, res.data);

            await client.sendFile(chatId, { file: filePath, forceDocument: false });

            try {
                await client.deleteMessages(chatId, [processing.id]);
            } catch {}

            fs.unlinkSync(filePath);
        } catch {
            await client.sendMessage(chatId, { 
                message: "<blockquote>❌ Gagal membuat stiker brat</blockquote>", 
                parseMode: "html" 
            });
        }
    }
};