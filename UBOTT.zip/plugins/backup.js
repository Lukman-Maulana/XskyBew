module.exports = {
    name: "backup",
    command: "backup",
    desc: "Backup Script",
    ownerOnly: true,
    
    async execute(client, event, prefix) {
        const chatId = event.message.chatId;
        
        const processingMsg = await client.sendMessage(chatId, { 
            message: "<blockquote>📦 Membuat backup...</blockquote>", 
            parseMode: "html" 
        });

        try {
            const archiver = require("archiver");
            const fs = require("fs");
            const path = require("path");

            const output = fs.createWriteStream('./ubotBew.zip');
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('close', async () => {
                await client.editMessage(chatId, {
                    message: processingMsg.id,
                    text: "<blockquote>✅ Backup berhasil dibuat!</blockquote>",
                    parseMode: "html"
                });

                await client.sendFile(chatId, {
                    file: './ubotBew.zip',
                    caption: `📦 Backup Ubot Bew - ${new Date().toLocaleString()}`
                });

                fs.unlinkSync('./ubotBew.zip');
            });

            archive.on('error', async (err) => {
                await client.editMessage(chatId, {
                    message: processingMsg.id,
                    text: `<blockquote>❌ Error: ${err.message}</blockquote>`,
                    parseMode: "html"
                });
            });

            archive.pipe(output);

            const filesToBackup = [
                'plugins',
                'config.js',
                'index.js',
                'package.json'
            ];

            filesToBackup.forEach(file => {
                if (fs.existsSync(file)) {
                    if (fs.statSync(file).isDirectory()) {
                        archive.directory(file, file);
                    } else {
                        archive.file(file, { name: file });
                    }
                }
            });

            archive.finalize();

        } catch (error) {
            await client.editMessage(chatId, {
                message: processingMsg.id,
                text: `<blockquote>❌ Error: ${error.message}</blockquote>`,
                parseMode: "html"
            });
        }
    }
};