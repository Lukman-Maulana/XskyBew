const axios = require("axios");

module.exports = {
  name: "xnxx",
  command: "xnxx",
  desc: "Cari video XNXX ",
  ownerOnly: true,

  async execute(client, event, prefix) {
    const msg = event.message;
    const chatId = msg.chatId;
    const query = (msg.message || "").split(" ").slice(1).join(" ").trim();

    if (!query) {
      return await client.sendMessage(chatId, {
        message: `<blockquote>Gunakan: ${prefix || "."}xnxx10 &lt;kata kunci&gt;\nContoh: ${prefix || "."}xnxx10 big tits</blockquote>`,
        parseMode: "html",
      });
    }

    // kirim loading
    const loadingMsg = await client.sendMessage(chatId, {
      message: `<blockquote>⏳ Mencari video ${query} ...</blockquote>`,
      parseMode: "html",
    });

    try {
      const apiUrl = `https://api.vreden.my.id/api/v1/search/xnxx?query=${encodeURIComponent(query)}`;
      const res = await axios.get(apiUrl, { timeout: 15000 });
      const data = res.data;

      if (!data?.status || !data?.result?.search_data?.length) {
        throw new Error("Tidak ada hasil ditemukan.");
      }

      const searchData = data.result.search_data.slice(0, 10); // ambil 10 pertama
      let text = `<blockquote><b>🔍 10 Hasil Pencarian XNXX untuk:</b> ${query}\n\n`;

      searchData.forEach((v, idx) => {
        text += `<b>${idx + 1}. ${v.title}</b>\n`;
        text += `${v.info.trim().replace(/\n/g, " ")}\n`;
        text += `🔗 <a href="${v.link}">Link Video</a>\n\n`;
      });
      text += "</blockquote>";


      // kirim pesan
      await client.sendMessage(chatId, { message: text, parseMode: "html" });

    } catch (e) {
      console.error("xnxx10 error:", e?.toString?.() || e);
      await client.deleteMessages(chatId, [loadingMsg.id]).catch(() => {});

      await client.sendMessage(chatId, {
        message: `<blockquote>❌ Terjadi kesalahan: ${e.message || e}</blockquote>`,
        parseMode: "html",
      });
    }
  },
};