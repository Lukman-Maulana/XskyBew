// plugins/payment.js
module.exports = {
    name: "payment",
    command: "payment",
    desc: "Informasi Payment",
    ownerOnly: true,
    execute: async (client, event, prefix) => {
        const chatId = event.message.chatId;
        
        // URL QRIS yang diberikan
        const qrisImageUrl = "https://img1.pixhost.to/images/5599/596307835_imgtmp.jpg";

        // Kirim gambar QRIS terlebih dahulu
        try {
            await client.sendFile(chatId, {
                file: qrisImageUrl,
                caption: `<blockquote><b>🏦 METODE PEMBAYARAN YANG TERSEDIA:</b>

<b>📱 DANA:</b>
➤ <code>0882003061918</code>
➤ <b>Atas Nama: Harxxx</b>

<b>📋 QRIS:</b>
➤ Scan QR Di Atas</blockquote>`,
                parseMode: "html"
            });
        } catch (error) {
            console.log('Error mengirim QRIS:', error);
            await client.sendMessage(chatId, {
                message: "<blockquote>❌ <b>GAGAL MENGIRIM GAMBAR QRIS</b>\n\nSilakan gunakan transfer manual ke nomor yang tertera.</blockquote>",
                parseMode: "html"
            });
        }
    }
};