const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

module.exports = {
    name: "bc",
    command: "bc",
    desc: "Broadcast pesan",
    ownerOnly: true,

    async execute(client, event, prefix) {
        const chatId = event.message.chatId;
        const args = event.message.text.split(" ").slice(1);
        const mode = args[0];
        const text = args.slice(1).join(" ");
        const replyMsg = await event.message.getReplyMessage();

        if (!mode) {
            await client.sendMessage(chatId, {
                message: `<blockquote>⚠️ Gunakan format:\n<code>${prefix}bc all teks</code>\natau reply media dengan:\n<code>${prefix}bc all</code></blockquote>`,
                parseMode: "html"
            });
            return;
        }

        if (!["all", "group"].includes(mode)) {
            await client.sendMessage(chatId, {
                message: `<blockquote>⚠️ Mode hanya <code>all</code> atau <code>group</code>.</blockquote>`,
                parseMode: "html"
            });
            return;
        }

        let caption = text || "";
        let media = null;

        if (replyMsg && replyMsg.media) {
            media = replyMsg.media;
            if (!caption && replyMsg.message) caption = replyMsg.message;
        }

        if (!caption && !media) {
            await client.sendMessage(chatId, {
                message: `<blockquote>⚠️ Tidak ada teks atau media untuk dikirim.</blockquote>`,
                parseMode: "html"
            });
            return;
        }

        const statusMsg = await client.sendMessage(chatId, {
            message: `<blockquote>⏳ <b>Broadcast dimulai...</b>\nMode: <code>${mode}</code></blockquote>`,
            parseMode: "html"
        });

        try {
            const dialogs = await client.getDialogs();
            let total = 0;
            let success = 0;

            for (const d of dialogs) {
                const chat = d.entity;
                if (!chat) continue;

                const isGroup = chat.className === "Chat" || chat.megagroup;
                const isUser = chat.className === "User";

                if (mode === "group" && !isGroup) continue;
                if (mode === "all" && !(isGroup || isUser)) continue;

                try {
                    if (media) {
                        await client.sendMessage(chat.id, {
                            file: media,
                            caption: `${caption}`,
                            parseMode: "html"
                        });
                    } else {
                        await client.sendMessage(chat.id, {
                            message: `${caption}`,
                            parseMode: "html"
                        });
                    }

                    success++;
                    total++;
                    await sleep(1500); // aman dari flood
                } catch {
                    total++;
                }
            }

            await client.editMessage(chatId, {
                message: statusMsg.id,
                text: `<blockquote>✅ <b>Broadcast selesai!</b>\nMode: <code>${mode}</code>\nBerhasil: ${success}\nTotal target: ${total}</blockquote>`,
                parseMode: "html"
            });
        } catch (err) {
            console.error(err);
            await client.editMessage(chatId, {
                message: statusMsg.id,
                text: `<blockquote>❌ Terjadi kesalahan!\n${err.message}</blockquote>`,
                parseMode: "html"
            });
        }
    }
};