const fetch = require("node-fetch");

module.exports = {
    name: "nik",
    command: "nik",
    desc: "Cek data NIK ",
    ownerOnly: true,
    execute: async (client, event, prefix) => {
        const chatId = event.message.chatId;
        const text = event.message.message.split(" ")[1];
        if (!text) {
            await client.sendMessage(chatId, { 
                message: `<blockquote>🔍 Masukkan NIK\nContoh: ${prefix}nik 3202285909840005</blockquote>`, 
                parseMode: "html" 
            });
            return;
        }
        try {
            const res = await fetch(`https://faa-jian.my.id/search/nik?nik=${text}`);
            const data = await res.json();
            if (!data.status) {
                await client.sendMessage(chatId, { 
                    message: `<blockquote>❌ Data tidak ditemukan</blockquote>`, 
                    parseMode: "html" 
                });
                return;
            }
            const r = data.result;
            let teks = `<blockquote>🔍 <b>Hasil Pencarian NIK</b>\n\n`;
            teks += `• NIK: ${r.nik}\n`;
            teks += `• Kelamin: ${r.kelamin}\n`;
            teks += `• Tanggal Lahir: ${r.lahir_lengkap}\n`;
            teks += `• Provinsi: ${r.provinsi.nama}\n`;
            teks += `• Kota/Kab: ${r.kotakab.jenis} ${r.kotakab.nama}\n`;
            teks += `• Kecamatan: ${r.kecamatan.nama}\n`;
            teks += `• Kode Wilayah: ${r.kode_wilayah}\n`;
            teks += `• Nomor Urut: ${r.nomor_urut}\n\n`;
            teks += `📌 Tambahan:\n`;
            teks += `- Pasaran: ${r.tambahan.pasaran}\n`;
            teks += `- Usia: ${r.tambahan.usia} (${r.tambahan.kategori_usia})\n`;
            teks += `- Ultah: ${r.tambahan.ultah}\n`;
            teks += `- Zodiak: ${r.tambahan.zodiak}</blockquote>`;
            await client.sendMessage(chatId, { message: teks, parseMode: "html" });
        } catch (e) {
            await client.sendMessage(chatId, { 
                message: `<blockquote>⚠️ Terjadi kesalahan saat mengambil data</blockquote>`, 
                parseMode: "html" 
            });
        }
    }
};