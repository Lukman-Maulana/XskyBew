const axios = require('axios');
const FormData = require('form-data');

module.exports = {
    name: "ttsearch",
    command: "ttsearch",
    desc: "Search Vt",
    ownerOnly: true,
    
    execute: async (client, event, prefix, startTime) => {
        const msg = event.message.message;
        const chatId = event.message.chatId;
        const args = msg.split(' ').slice(1);
        const query = args.join(' ');
        
        let processingMsg;
        
        try {
            if (!query) {
                await client.sendMessage(chatId, {
                    message: `<blockquote>🔍 Pencarian TikTok\n\nFormat: ${prefix}ttsearch [kata kunci]\n\nContoh:\n${prefix}ttsearch dance viral\n${prefix}ttsearch trending videos</blockquote>`,
                    parseMode: "html"
                });
                return;
            }
            
            processingMsg = await client.sendMessage(chatId, {
                message: `<blockquote>⏳ Mencari video TikTok...</blockquote>`,
                parseMode: "html"
            });
            
            const searchResults = await ttSearch(query);
            
            if (!searchResults || searchResults.length === 0) {
                await client.editMessage(chatId, {
                    message: processingMsg.id,
                    text: `<blockquote>❌ Tidak ditemukan hasil untuk "${query}"</blockquote>`,
                    parseMode: "html"
                });
                return;
            }
            
            const firstVideo = searchResults[0];
            
            await client.editMessage(chatId, {
                message: processingMsg.id,
                text: `<blockquote>⏳ Mengunduh video...</blockquote>`,
                parseMode: "html"
            });
            
            let caption = `<blockquote>🎬 Video TikTok\n\n`;
            caption += `Judul: ${firstVideo.title || 'Tanpa judul'}\n`;
            caption += `Pembuat: ${firstVideo.author?.nickname || 'Tidak diketahui'}\n`;
            caption += `Durasi: ${firstVideo.duration} detik\n`;
            caption += `Views: ${firstVideo.play_count}\n`;
            caption += `Like: ${firstVideo.digg_count}\n`;
            caption += `</blockquote>`;
                   
        try {
                await client.sendFile(chatId, {
                    file: firstVideo.play,
                    caption: caption,
                    parseMode: "html",
                    attributes: [{
                        _: 'documentAttributeVideo',
                        duration: parseInt(firstVideo.duration) || 0,
                        w: 720,
                        h: 1280
                    }]
                });
                
            } catch (uploadError) {
            console.log("eror ttsearch");
            }
            
        } catch (err) {
            console.error('Error TikTok search:', err);
            
            if (processingMsg) {
                await client.editMessage(chatId, {
                    message: processingMsg.id,
                    text: `<blockquote>❌ Terjadi kesalahan saat mencari video\n${err.message}</blockquote>`,
                    parseMode: "html"
                });
            } else {
                await client.sendMessage(chatId, {
                    message: `<blockquote>❌ Terjadi kesalahan saat mencari video\n${err.message}</blockquote>`,
                    parseMode: "html"
                });
            }
        }
    }
};

async function ttSearch(query) {
    try {
        let d = new FormData();
        d.append("keywords", query);
        d.append("count", 15);
        d.append("cursor", 0);
        d.append("web", 1);
        d.append("hd", 1);
 
        let h = {
            headers: {
                ...d.getHeaders()
            },
            timeout: 30000
        }
 
        let { data } = await axios.post("https://tikwm.com/api/feed/search", d, h);
 
        if (!data || !data.data || !data.data.videos) {
            throw new Error('Format response tidak valid');
        }
 
        const baseURL = "https://tikwm.com";
 
        const videos = data.data.videos.map(video => {
            return {
                ...video,
                play: baseURL + video.play,
                wmplay: baseURL + video.wmplay,
                music: baseURL + video.music,
                cover: baseURL + video.cover,
                avatar: baseURL + video.avatar,
                music_info: video.music_info ? {
                    ...video.music_info,
                    play: baseURL + video.music_info.play
                } : null
            };
        });
 
        return videos;
    } catch (e) {
        throw new Error(`Gagal mengambil data: ${e.message}`);
    }
}