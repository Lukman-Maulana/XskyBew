const axios = require("axios");

module.exports = {
  name: "ig",
  command: "ig",
  desc: "Download video Instagram",
  ownerOnly: true,

  async execute(client, event, prefix) {
    try {
      const msg = event.message;
      const chatId = msg.chatId;
      const text = msg.message || "";
      const args = text.split(/\s+/).slice(1);
      const link = args[0];

      if (!link) {
        return client.sendMessage(chatId, { message: "<blockquote>⚠️ Kirim link Instagram-nya!</blockquote>", parseMode: "html" });
      }

      await client.sendMessage(chatId, { message: "<blockquote>⏳ Mengambil data dari Instagram...</blockquote>", parseMode: "html" });

      const api = `https://api.vreden.my.id/api/v1/download/instagram?url=${encodeURIComponent(link)}`;
      const res = await axios.get(api);
      const data = res.data?.result;

      if (!data) return client.sendMessage(chatId, { message: "<blockquote>❌ Tidak mendapatkan data dari API.</blockquote>", parseMode: "html" });

      const media = data.data?.[0];
      if (!media || !media.url) {
        return client.sendMessage(chatId, { message: "<blockquote>❌ Tidak menemukan media di postingan tersebut.</blockquote>", parseMode: "html" });
      }

      const caption = `<blockquote>
📸 <b>${data.profile.full_name}</b> (@${data.profile.username})${data.profile.is_verified ? " ✅" : ""}
💬 ${data.caption.text || "Tidak ada caption"}
❤️ ${data.statistics.like_count?.toLocaleString() || 0} | 💬 ${data.statistics.comment_count?.toLocaleString() || 0} | 🔁 ${data.statistics.share_count?.toLocaleString() || 0}</blockquote>`.trim();

      await client.sendFile(chatId, {
        file: media.url,
        caption,
        parseMode: "html"
      });

    } catch (e) {
      console.error(e);
      await client.sendMessage(event.message.chatId, { message: `❌ Terjadi error: ${e.message}` });
    }
  }
};