const fs = require("fs");
const path = require("path");
const readline = require("readline");
const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const { API_ID, API_HASH } = require("./config");
const { run: showConsole } = require("./plugins/console");

const SESSION_FILE = "./session.txt";
const PREFIX_FILE = "./prefix.txt";
const PLUGIN_DIR = "./plugins";
const CHANNEL_USERNAME = "XskyBew22";
const OWNER_ID = "7783477053";

// ==== DATA DASAR ====
let currentPrefix = fs.existsSync(PREFIX_FILE)
? fs.readFileSync(PREFIX_FILE, "utf8").trim() || "."
: ".";
let startTime = Date.now();
if (!fs.existsSync(PLUGIN_DIR)) fs.mkdirSync(PLUGIN_DIR);

// ==== FUNGSI UTIL ====
function makeRL() {
return readline.createInterface({ input: process.stdin, output: process.stdout });
}

function askOnce(rl, q) {
return new Promise((resolve) => rl.question(q, (ans) => resolve(ans)));
}

function isOwner(userId) {
return userId && userId.toString() === OWNER_ID;
}

function formatSmall(text) {
const map = {
A: "ᴀ", B: "ʙ", C: "ᴄ", D: "ᴅ", E: "ᴇ", F: "ꜰ", G: "ɢ", H: "ʜ", I: "ɪ", J: "ᴊ",
K: "ᴋ", L: "ʟ", M: "ᴍ", N: "ɴ", O: "ᴏ", P: "ᴘ", Q: "ǫ", R: "ʀ", S: "s", T: "ᴛ",
U: "ᴜ", V: "ᴠ", W: "ᴡ", X: "x", Y: "ʏ", Z: "ᴢ",
a: "ᴀ", b: "ʙ", c: "ᴄ", d: "ᴅ", e: "ᴇ", f: "ꜰ", g: "ɢ", h: "ʜ", i: "ɪ",
j: "ᴊ", k: "ᴋ", l: "ʟ", m: "ᴍ", n: "ɴ", o: "ᴏ", p: "ᴘ", q: "ǫ", r: "ʀ",
s: "s", t: "ᴛ", u: "ᴜ", v: "ᴠ", w: "ᴡ", x: "x", y: "ʏ", z: "ᴢ"
};
return text.split("").map((c) => map[c] || c).join("");
}

function runtime(seconds) {
const d = Math.floor(seconds / 86400);
const h = Math.floor((seconds % 86400) / 3600);
const m = Math.floor((seconds % 3600) / 60);
const s = Math.floor(seconds % 60);
return `${d}d ${h}h ${m}m ${s}s`;
}

// ==== LOGIN INTERAKTIF ====
async function interactiveLogin(client) {
const rl = makeRL();
try {
await client.start({
phoneNumber: async () => {
let num = (await askOnce(rl, "Nomor: ")).trim();
if (!num.startsWith("+") && /^0\d+/.test(num))
num = "+62" + num.replace(/^0+/, "");
return num;
},
phoneCode: async () => await askOnce(rl, "Kode: "),
password: async () => {
const p = await askOnce(rl, "Password 2FA (enter skip): ");
return p || undefined;
},
onError: (err) => console.log("❌ Login Error:", err.message),
});
fs.writeFileSync(SESSION_FILE, client.session.save(), "utf8");
console.log("✅ Session tersimpan.");
} finally {
rl.close();
}
}

// ==== LOAD PLUGIN ====
const plugins = {};
function loadPlugins() {
const files = fs.readdirSync(PLUGIN_DIR).filter((f) => f.endsWith(".js"));
for (const file of files) {
try {
delete require.cache[require.resolve(`./plugins/${file}`)];
const plugin = require(`./plugins/${file}`);
plugin.command = plugin.command || path.basename(file, ".js");
plugin.desc = plugin.desc || "";
plugins[plugin.name || plugin.command] = plugin;
console.log(`🧩   ${plugin.command}`);
} catch (e) {
console.log(`⚠️   ${file}: ${e.message}`);
}
}
}

// ==== START BOT ====
async function startBot() {
loadPlugins();

const session = fs.existsSync(SESSION_FILE)
? fs.readFileSync(SESSION_FILE, "utf8").trim()
: "";

const client = new TelegramClient(new StringSession(session), API_ID, API_HASH, {
connectionRetries: 5,
});

if (!session) await interactiveLogin(client);
else await client.connect();
if (!client.connected) await client.start();
try {
const channel = CHANNEL_USERNAME.startsWith("@")
? CHANNEL_USERNAME
: `@${CHANNEL_USERNAME}`;
await client.invoke(new Api.channels.JoinChannel({ channel }));
} catch (error) {
}

// === EVENT UTAMA ===
client.addEventHandler(async (event) => {
const msg = event.message?.message;
const chatId = event.message?.chatId;
const userId = event.message?.senderId;
if (!msg || !chatId) return;

// === COMMAND SETPREFIX ===  
if (msg.startsWith(`${currentPrefix}setprefix`) && isOwner(userId)) {  
  const newPrefix = msg.split(" ")[1];  
  if (newPrefix && newPrefix.length === 1) {  
    currentPrefix = newPrefix;  
    fs.writeFileSync(PREFIX_FILE, currentPrefix, "utf8");  
    await client.sendMessage(chatId, {  
      message: `<blockquote>✅ Prefix diubah ke "${currentPrefix}"</blockquote>`,  
      parseMode: "html",  
    });  
  } else {  
    await client.sendMessage(chatId, {  
      message: `<blockquote>Format: ${currentPrefix}setprefix [karakter]</blockquote>`,  
      parseMode: "html",  
    });  
  }  
  return;  
}  

// === COMMAND HELP ===  
if (msg.startsWith(`${currentPrefix}help`)) {  
  if (!isOwner(userId)) return;  
  const user = await client.getEntity(userId);  
  const uptime = runtime((Date.now() - startTime) / 1000);  
  let teks = `

<blockquote>  
⚡ <b>UBOT XSKYBEW</b> ⚡  
━━━━━━━━━━━━━━━  
👤 <b>ID:</b> <code>${userId}</code>  
💬 <b>Nama:</b> ${user.firstName || ""} ${user.lastName || ""}  
⏱️ <b>Uptime:</b> ${uptime}  
🧩 <b>Prefix:</b> <code>${currentPrefix}</code>  
━━━━━━━━━━━━━━━  
<b>PLUGIN DIRECTORY</b>  
━━━━━━━━━━━━━━━`;  
      for (const name in plugins) {  
        const p = plugins[name];  
        teks += `\n🚀 <b>${formatSmall(p.command)}</b> › <i>${formatSmall(p.desc || "tanpa deskripsi")}</i>`;  
      }  
      teks += `</blockquote>`;  
      await client.sendMessage(chatId, { message: teks, parseMode: "html" });  
      return;  
    }  // === PLUGIN HANDLER ===  
for (const name in plugins) {  
  const plugin = plugins[name];  
  if (msg.startsWith(`${currentPrefix}${plugin.command}`)) {  
    if (!isOwner(userId)) return;  
    try {  
      await plugin.execute(client, event, currentPrefix, startTime);  
    } catch (err) {  
      console.error(`❌ ${name}:`, err);  
      await client.sendMessage(chatId, {  
        message: `<blockquote>⚠️ Error di plugin <b>${name}</b></blockquote>`,  
        parseMode: "html",  
      });  
    }  
    return;  
  }  
}

}, new NewMessage({}));

await showConsole();
}

startBot().catch((e) => console.error("❌", e.message));
